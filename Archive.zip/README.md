# How to run:
1. Navigate into the project root.
2. `npm install` will install all dependencies
3. `npm start` will run the app on port 3000
4. Open your browser and go to localhost:3000

### Nice to knows:
- Submit tags by pressing enter key
- Let me know if you have any questions / problems, I can be contacted through:
- Github: ben-che
- Repo: https://github.com/ben-che/hw-coding-challenge-frontend
- website: ben-che.com
- email: ben.che9@gmail.com

Thanks for your time!