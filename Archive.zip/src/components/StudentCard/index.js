export { default } from './StudentCard';
