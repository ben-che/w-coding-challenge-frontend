import Input from './Input';
import TagInput from './TagInput';

export { Input, TagInput };
